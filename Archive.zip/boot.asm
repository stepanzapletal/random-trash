[org 0x7C00]       ; boot sector is loaded at 0x7C00

mov si, msg         ; point si to address of message

loop_start:
    mov al, [si]   ; AL = memory at SI
    inc si         ; SI = SI + 1
    cmp al, 0      ; Compare AL to 0
    je done        ; if equal, jump to done
    mov ah, 0x0E   ; puts 0x0E in AH for bios to know
    int 0x10       ; call interrupt to print AL
    jmp loop_start ; jump back to the start of the loop

done:
    cli            ; clear interrupts
    hlt            ; halt the CPU

msg db 'Hello World!', 0 ; define message, null terminated

; pad everything until byte 510
times 510-($-$$) db 0

; boot signature (last 2 bytes must be 0xAA55)
dw 0xAA55