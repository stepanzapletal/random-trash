[org 0x7C00]       ; boot sector is loaded at 0x7C00

start:
    mov ah, 0x00   ; set AH to 0 for keyboard input
    int 0x16       ; call interrupt to read a key from the keyboard
    mov ah, 0x0E   ; ah is a function number for the BIOS teletype output
    int 0x10       ; call interrupt to print
    jmp start       ; jump back to the start to read another key
    
; pad everything until byte 510
times 510-($-$$) db 0

; boot signature (last 2 bytes must be 0xAA55)
dw 0xAA55